class SwiftMethod < SwiftEntityElement
end
