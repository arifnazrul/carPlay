class SwiftProperty < SwiftEntityElement
end
