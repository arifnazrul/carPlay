var entities = [{
  "id": 1,
  "typeString": "class",
  "methods": [
    {
  "name": "handler(for intent: INIntent) -> Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "IntentHandler",
  "superClass": 192
},{
  "id": 2,
  "typeString": "class",
  "methods": [
    {
  "name": "resolveDate(for intent: CreateNoteIntent, with completion: @escaping (INStringResolutionResult) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "resolveCreateReminderPrompt(for intent: CreateNoteIntent, with completion: @escaping (Enum5ResolutionResult) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "resolveFieldName(for intent: CreateNoteIntent, with completion: @escaping (Enum2ResolutionResult) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "resolveCreateNotePrompt(for intent: CreateNoteIntent, with completion: @escaping (Enum1ResolutionResult) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "handle(intent: CreateNoteIntent, completion: @escaping (CreateNoteIntentResponse) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "resolveNoteType(for intent: CreateNoteIntent, with completion: @escaping (EnumResolutionResult) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "resolveContent(for intent: CreateNoteIntent, with completion: @escaping (INStringResolutionResult) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    194
  ],
  "name": "CreateNoteIntentHandler",
  "superClass": 193
},{
  "id": 3,
  "typeString": "class",
  "properties": [
    {
  "name": "var desiredSize: CGSize",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "viewDidLoad()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "configureView(for parameters: Set<INParameter>, of interaction: INInteraction, interactiveBehavior: INUIInteractiveBehavior, context: INUIHostedViewContext, completion: @escaping (Bool, Set<INParameter>, CGSize) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    196
  ],
  "name": "IntentViewController",
  "superClass": 195
},{
  "id": 4,
  "typeString": "class",
  "properties": [
    {
  "name": "var ID_Organization",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var name: String? @objc dynamic",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var desc: String?",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "primaryKey() -> String?",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "Organization",
  "superClass": 169
},{
  "id": 5,
  "typeString": "class",
  "properties": [
    {
  "name": "var ID_User",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var username: String? @objc dynamic",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var password: String?",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "primaryKey() -> String?",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "User",
  "superClass": 169
},{
  "id": 6,
  "typeString": "class",
  "properties": [
    {
  "name": "var ID_UserOrganization",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var User_ID",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var Organization_ID",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "primaryKey() -> String?",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "UserOrganization",
  "superClass": 169
},{
  "id": 7,
  "typeString": "class",
  "properties": [
    {
  "name": "var ID_Field",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var Organization_ID",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var name: String? @objc dynamic",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var coordinates: String?",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "primaryKey() -> String?",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "Field",
  "superClass": 169
},{
  "id": 8,
  "typeString": "class",
  "properties": [
    {
  "name": "var ID_Note",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var Field_ID",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var content: String? @objc dynamic",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var date: Date?",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "primaryKey() -> String?",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "Note",
  "superClass": 169
},{
  "id": 9,
  "typeString": "class",
  "properties": [
    {
  "name": "var ID_Notification",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var Field_ID",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var content: String? @objc dynamic",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var severity: String? @objc dynamic",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var dateCreated: Date?",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "primaryKey() -> String?",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "Notification",
  "superClass": 169
},{
  "id": 10,
  "typeString": "class",
  "properties": [
    {
  "name": "var ID_Visit",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var User_ID",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var Field_ID",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var lastVisit: Date?",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "primaryKey() -> String?",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "Visit",
  "superClass": 169
},{
  "id": 11,
  "typeString": "class",
  "properties": [
    {
  "name": "var data: NSDictionary",
  "type": "instance",
  "accessLevel": "private"
}
  ],
  "methods": [
    {
  "name": "createUsers(usersArray: NSArray) -> [User]",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "createOrganizations(organizationsArray: NSArray) -> [Organization]",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "createUserOrganizations(userOrganizationsArray: NSArray) -> [UserOrganization]",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "createFields(fieldsArray: NSArray) -> [Field]",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "createVisits(visitsArray: NSArray) -> [Visit]",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "createNotifications(notificationsArray: NSArray) -> [Notification]",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "createNote(noteArray: NSArray) -> [Note]",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "stringToDate(date: String) -> Date",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "init(path: String)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "DatabaseConfiguration"
},{
  "id": 12,
  "typeString": "enum",
  "cases": [
    {
  "name": "search"
},
    {
  "name": "panning"
},
    {
  "name": "dismiss"
}
  ],
  "name": "BarButtonType",
  "superClass": 197
},{
  "id": 13,
  "typeString": "class",
  "properties": [
    {
  "name": "var carWindow: CPWindow?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var interfaceController: CPInterfaceController?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var mapTemplate: CPMapTemplate?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var cp: CarPlayViewController?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let sharedInstance: AppDelegate",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "var window: UIWindow?",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "application(_ application: UIApplication, didConnectCarInterfaceController interfaceController: CPInterfaceController, to window: CPWindow)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "createTemplate() -> CPMapTemplate",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "mapTemplateWillDismissPanningInterface(_ mapTemplate: CPMapTemplate)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "createBarButton(_ type: BarButtonType) -> CPBarButton",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "mapTemplate(_ mapTemplate: CPMapTemplate, panEndedWith direction: CPMapTemplate.PanDirection)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "application(_ application: UIApplication, didDisconnectCarInterfaceController interfaceController: CPInterfaceController, from window: CPWindow)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    199,
    200,
    201
  ],
  "name": "AppDelegate",
  "superClass": 198,
  "containedEntities": [
    12
  ]
},{
  "id": 14,
  "typeString": "class",
  "properties": [
    {
  "name": "var title: String?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var subtitle: String?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var coordinate: CLLocationCoordinate2D",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "getPlaces() -> [[PlacesFraunhofer]]",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "init(title: String?, subtitle: String?, coordinate: CLLocationCoordinate2D)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "PlacesFraunhofer",
  "superClass": 193,
  "extensions": [
    15
  ]
},{
  "id": 16,
  "typeString": "class",
  "properties": [
    {
  "name": "var mapView: MKMapView!",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var mainView: UIView?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var lat : Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var long : Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var offsetLat : Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var offsetLong: Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var tractorPositionLat: Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var tractorPositionLong: Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var flagPositionLat: Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var flagPositionLong: Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var flagPositionLat2: Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var flagPositionLong2: Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var notePositionLat: Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var notePositionLong: Double",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var radius : Double!",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var interval",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var tick",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var growth",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var changeCounter: Int",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var overlays: [MKOverlay]!",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var tractorOverlay: [MKAnnotation]!",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let locationManager",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let fields",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let borders: [[CGFloat]]",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let inside: [[CGFloat]]",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var iterator: Int",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var changedPosition: Bool",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "viewDidLoad()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "moveUser()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "addTractor()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "addAnnotations()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "addSecondAnnotations()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "addPolyline()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "addPolygon()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "checkLocationServices()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "setupLocationManager()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "checkLocationAuthorization()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "CarPlayViewController",
  "superClass": 195
},{
  "id": 17,
  "typeString": "class",
  "methods": [
    {
  "name": "createNote(intent : CreateNoteIntent) -> Bool",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "CreateNoteController"
},{
  "id": 18,
  "typeString": "class",
  "methods": [
    {
  "name": "fetchUpdates(completion: @escaping (String) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "LastVisitController"
},{
  "id": 19,
  "typeString": "struct",
  "properties": [
    {
  "name": "var body: some View",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "ContentView",
  "superClass": 202
},{
  "id": 20,
  "typeString": "struct",
  "properties": [
    {
  "name": "var previews: some View",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "ContentView_Previews",
  "superClass": 203
},{
  "id": 21,
  "typeString": "class",
  "properties": [
    {
  "name": "var window: UIWindow?",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "donateInteraction()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "donateInteractionCreateNote()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "donateInteractionMachineAlerts()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sceneDidDisconnect(_ scene: UIScene)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sceneDidBecomeActive(_ scene: UIScene)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sceneWillResignActive(_ scene: UIScene)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sceneWillEnterForeground(_ scene: UIScene)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sceneDidEnterBackground(_ scene: UIScene)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "SceneDelegate",
  "superClass": 198
},{
  "id": 22,
  "typeString": "class",
  "properties": [
    {
  "name": "var desiredSize: CGSize",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "viewDidLoad()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "configureView(for parameters: Set<INParameter>, of interaction: INInteraction, interactiveBehavior: INUIInteractiveBehavior, context: INUIHostedViewContext, completion: @escaping (Bool, Set<INParameter>, CGSize) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "IntentViewController",
  "superClass": 195
},{
  "id": 23,
  "typeString": "class",
  "methods": [
    {
  "name": "handler(for intent: INIntent) -> Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "IntentHandler",
  "superClass": 192
},{
  "id": 24,
  "typeString": "class",
  "methods": [
    {
  "name": "resolveFieldName(for intent: LastVisitIntent, with completion: @escaping (Enum3ResolutionResult) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "handle(intent: LastVisitIntent, completion: @escaping (LastVisitIntentResponse) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "LastVisitIntentHandler",
  "superClass": 193
},{
  "id": 25,
  "typeString": "class",
  "methods": [
    {
  "name": "handler(for intent: INIntent) -> Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "IntentHandler",
  "superClass": 192
},{
  "id": 26,
  "typeString": "class",
  "methods": [
    {
  "name": "setUp()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "tearDown()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "testExample()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "testLaunchPerformance()",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "JD_FarmerUITests",
  "superClass": 204
},{
  "id": 27,
  "typeString": "struct",
  "properties": [
    {
  "name": "var defaultConfiguration: Configuration",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "var syncConfiguration: SyncConfiguration?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var _syncConfiguration: SyncConfiguration?",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "var fileURL: URL?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var _path: String?",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "var inMemoryIdentifier: String?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var _inMemoryIdentifier: String?",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "var encryptionKey: Data?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var readOnly: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var schemaVersion: UInt64",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var migrationBlock: MigrationBlock?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var deleteRealmIfMigrationNeeded: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var shouldCompactOnLaunch: ((Int, Int) -> Bool)?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var objectTypes: [Object.Type]?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var customSchema: RLMSchema?",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "var disableFormatUpgrade: Bool",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var rlmConfiguration: RLMRealmConfiguration",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let configuration",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let fileURL",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let inMemoryIdentifier",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let syncConfiguration",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let shouldCompactOnLaunch",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "fromRLMRealmConfiguration(_ rlmConfiguration: RLMRealmConfiguration) -> Configuration",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "init(fileURL: URL? = URL(fileURLWithPath: RLMRealmPathForFile(), isDirectory: false), inMemoryIdentifier: String? = nil, syncConfiguration: SyncConfiguration? = nil, encryptionKey: Data? = nil, readOnly: Bool = false, schemaVersion: UInt64 = 0, migrationBlock: MigrationBlock? = nil, deleteRealmIfMigrationNeeded: Bool = false, shouldCompactOnLaunch: ((Int, Int) -> Bool)? = nil, objectTypes: [Object.Type]? = nil)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "Configuration"
},{
  "id": 30,
  "typeString": "struct",
  "properties": [
    {
  "name": "let rlmTask: RLMAsyncOpenTask",
  "type": "instance",
  "accessLevel": "fileprivate"
}
  ],
  "methods": [
    {
  "name": "cancel()",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "addProgressNotification(queue: DispatchQueue = .main, block: @escaping (SyncSession.Progress) -> Void)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "AsyncOpenTask"
},{
  "id": 31,
  "typeString": "enum",
  "cases": [
    {
  "name": "error"
},
    {
  "name": "modified"
},
    {
  "name": "all"
}
  ],
  "name": "UpdatePolicy",
  "superClass": 205
},{
  "id": 32,
  "typeString": "class",
  "properties": [
    {
  "name": "var schema: Schema",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var configuration: Configuration",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isEmpty: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isInWriteTransaction: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var autorefresh: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var rlmRealm: RLMRealm",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "asyncOpen(configuration: Realm.Configuration = .defaultConfiguration, callbackQueue: DispatchQueue = .main, callback: @escaping (Realm?, Swift.Error?) -> Void) -> AsyncOpenTask",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "write(withoutNotifying tokens: [NotificationToken] = [], _ block: (() throws -> Void)) throws",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "beginWrite()",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "commitWrite(withoutNotifying tokens: [NotificationToken] = []) throws",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "cancelWrite()",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "add(_ object: Object, update: Bool)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "add(_ object: Object, update: UpdatePolicy = .error)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "add<S: Sequence>(_ objects: S, update: Bool) where S.Iterator.Element: Object",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "add<S: Sequence>(_ objects: S, update: UpdatePolicy = .error) where S.Iterator.Element: Object",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "create<T: Object>(_ type: T.Type, value: Any = [:], update: Bool) -> T",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "create<T: Object>(_ type: T.Type, value: Any = [:], update: UpdatePolicy = .error) -> T",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "dynamicCreate(_ typeName: String, value: Any = [:], update: Bool) -> DynamicObject",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "dynamicCreate(_ typeName: String, value: Any = [:], update: UpdatePolicy = .error) -> DynamicObject",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "delete(_ object: Object)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "delete<S: Sequence>(_ objects: S) where S.Iterator.Element: Object",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "delete<Element: Object>(_ objects: List<Element>)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "delete<Element: Object>(_ objects: Results<Element>)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "deleteAll()",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "objects<Element: Object>(_ type: Element.Type) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "dynamicObjects(_ typeName: String) -> Results<DynamicObject>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "object<Element: Object, KeyType>(ofType type: Element.Type, forPrimaryKey key: KeyType) -> Element?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "dynamicObject(ofType typeName: String, forPrimaryKey key: Any) -> DynamicObject?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "observe(_ block: @escaping NotificationBlock) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "refresh() -> Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "invalidate()",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "writeCopy(toFile fileURL: URL, encryptionKey: Data? = nil) throws",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init() throws",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "init(configuration: Configuration) throws",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "init(fileURL: URL) throws",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "init(_ rlmRealm: RLMRealm)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "Realm",
  "containedEntities": [
    30,
    31
  ],
  "extensions": [
    29,
    34,
    35,
    40,
    96,
    102,
    116,
    168
  ]
},{
  "id": 33,
  "typeString": "enum",
  "cases": [
    {
  "name": "didChange"
},
    {
  "name": "refreshRequired"
}
  ],
  "name": "Notification",
  "superClass": 197
},{
  "id": 37,
  "typeString": "struct",
  "properties": [
    {
  "name": "let rlmProperty: RLMProperty",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var name: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var type: PropertyType",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isArray: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isIndexed: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isOptional: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var objectClassName: String?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "init(_ rlmProperty: RLMProperty)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "Property",
  "superClass": 206,
  "extensions": [
    38
  ]
},{
  "id": 39,
  "typeString": "struct",
  "properties": [
    {
  "name": "let fail: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let fileAccess: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let filePermissionDenied: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let fileExists: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let fileNotFound: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let incompatibleLockFile: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let fileFormatUpgradeRequired: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let addressSpaceExhausted: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let schemaMismatch: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let incompatibleSyncedFile: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "var code: Code",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let _nsError: NSError",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var backupConfiguration: Realm.Configuration?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let configuration",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "init(_nsError error: NSError)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "Error"
},{
  "id": 41,
  "typeString": "struct",
  "properties": [
    {
  "name": "var generatorBase: NSFastEnumerationIterator",
  "type": "instance",
  "accessLevel": "private"
}
  ],
  "methods": [
    {
  "name": "next() -> Element?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "init(collection: RLMCollection)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "RLMIterator",
  "superClass": 207
},{
  "id": 42,
  "typeString": "enum",
  "methods": [
    {
  "name": "fromObjc(value: CollectionType, change: RLMCollectionChange?, error: Error?) -> RealmCollectionChange",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "cases": [
    {
  "name": "initial"
},
    {
  "name": "update"
},
    {
  "name": "error"
}
  ],
  "name": "RealmCollectionChange"
},{
  "id": 43,
  "typeString": "protocol",
  "methods": [
    {
  "name": "_rlmArray() -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "_nilValue() -> Self",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "RealmCollectionValue",
  "superClass": 208,
  "extensions": [
    51
  ]
},{
  "id": 44,
  "typeString": "protocol",
  "protocols": [
    210
  ],
  "name": "RealmCollectionBase",
  "superClass": 206
},{
  "id": 45,
  "typeString": "protocol",
  "properties": [
    {
  "name": "var realm: Realm?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var isInvalidated: Bool",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var count: Int",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "index(of object: Element) -> Int?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "index(matching predicate: NSPredicate) -> Int?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "index(matching predicateFormat: String, _ args: Any...) -> Int?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "filter(_ predicateFormat: String, _ args: Any...) -> Results<Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "filter(_ predicate: NSPredicate) -> Results<Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sorted(byKeyPath keyPath: String, ascending: Bool) -> Results<Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sorted<S: Sequence>(by sortDescriptors: S) -> Results<Element> where S.Iterator.Element == SortDescriptor",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "min<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "max<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sum<T: AddableType>(ofProperty property: String) -> T",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "average(ofProperty property: String) -> Double?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "value(forKey key: String) -> Any?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "value(forKeyPath keyPath: String) -> Any?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "setValue(_ value: Any?, forKey key: String)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "observe(_ block: @escaping (RealmCollectionChange<Self>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "_observe(_ block: @escaping (RealmCollectionChange<AnyRealmCollection<Element>>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    44
  ],
  "name": "RealmCollection",
  "extensions": [
    65,
    66,
    67,
    68,
    69,
    70,
    72
  ]
},{
  "id": 46,
  "typeString": "protocol",
  "methods": [
    {
  "name": "_rlmInferWrappedType() -> Wrapped",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "OptionalProtocol"
},{
  "id": 47,
  "typeString": "class",
  "properties": [
    {
  "name": "var realm: Realm?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var isInvalidated: Bool",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var count: Int",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var startIndex: Int",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var endIndex: Int",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var bridged: (objectiveCValue: Any, metadata: Any?)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "index(of object: Element) -> Int?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "index(matching predicate: NSPredicate) -> Int?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "index(matching predicateFormat: String, _ args: Any...) -> Int?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "filter(_ predicateFormat: String, _ args: Any...) -> Results<Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "filter(_ predicate: NSPredicate) -> Results<Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sorted(byKeyPath keyPath: String, ascending: Bool) -> Results<Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sorted<S: Sequence>(by sortDescriptors: S) -> Results<Element> where S.Iterator.Element == SortDescriptor",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "min<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "max<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sum<T: AddableType>(ofProperty property: String) -> T",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "average(ofProperty property: String) -> Double?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "makeIterator() -> RLMIterator<T>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "value(forKey key: String) -> Any?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "value(forKeyPath keyPath: String) -> Any?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "setValue(_ value: Any?, forKey key: String)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "_observe(_ block: @escaping (RealmCollectionChange<Wrapper>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "bridging(from objectiveCValue: Any, with metadata: Any?) -> Self",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    154
  ],
  "name": "_AnyRealmCollectionBase"
},{
  "id": 48,
  "typeString": "class",
  "properties": [
    {
  "name": "let base: C override",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var realm: Realm?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var isInvalidated: Bool",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var count: Int",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var startIndex: Int",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var endIndex: Int",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var bridged: (objectiveCValue: Any, metadata: Any?)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "index(of object: C.Element) -> Int?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "index(matching predicate: NSPredicate) -> Int?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "index(matching predicateFormat: String, _ args: Any...) -> Int?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "filter(_ predicateFormat: String, _ args: Any...) -> Results<C.Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "filter(_ predicate: NSPredicate) -> Results<C.Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sorted(byKeyPath keyPath: String, ascending: Bool) -> Results<C.Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sorted<S: Sequence> (by sortDescriptors: S) -> Results<C.Element> where S.Iterator.Element == SortDescriptor",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "min<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "max<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "sum<T: AddableType>(ofProperty property: String) -> T",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "average(ofProperty property: String) -> Double?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "makeIterator() -> RLMIterator<Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "value(forKey key: String) -> Any?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "value(forKeyPath keyPath: String) -> Any?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "setValue(_ value: Any?, forKey key: String)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "_observe(_ block: @escaping (RealmCollectionChange<Wrapper>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "bridging(from objectiveCValue: Any, with metadata: Any?) -> _AnyRealmCollection",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "init(base: C)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "_AnyRealmCollection"
},{
  "id": 49,
  "typeString": "class",
  "properties": [
    {
  "name": "let base: _AnyRealmCollectionBase<Element>",
  "type": "instance",
  "accessLevel": "fileprivate"
},
    {
  "name": "var realm: Realm?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isInvalidated: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var count: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var startIndex: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var endIndex: Int",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "index(after i: Int) -> Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(before i: Int) -> Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(of object: Element) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(matching predicate: NSPredicate) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(matching predicateFormat: String, _ args: Any...) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "filter(_ predicateFormat: String, _ args: Any...) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "filter(_ predicate: NSPredicate) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sorted(byKeyPath keyPath: String, ascending: Bool) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sorted<S: Sequence>(by sortDescriptors: S) -> Results<Element> where S.Iterator.Element == SortDescriptor",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "min<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "max<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sum<T: AddableType>(ofProperty property: String) -> T",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "average(ofProperty property: String) -> Double?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "makeIterator() -> RLMIterator<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "value(forKey key: String) -> Any?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "value(forKeyPath keyPath: String) -> Any?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "setValue(_ value: Any?, forKey key: String)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "observe(_ block: @escaping (RealmCollectionChange<AnyRealmCollection>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "_observe(_ block: @escaping (RealmCollectionChange<AnyRealmCollection>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(base: _AnyRealmCollectionBase<Element>)",
  "type": "instance",
  "accessLevel": "fileprivate"
},
    {
  "name": "init<C: RealmCollection>(_ base: C) where C.Element == Element",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    45
  ],
  "name": "AnyRealmCollection",
  "extensions": [
    71
  ]
},{
  "id": 50,
  "typeString": "struct",
  "properties": [
    {
  "name": "var baseMetadata: Any?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var baseType: _AnyRealmCollectionBase<T>.Type",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "AnyRealmCollectionBridgingMetadata"
},{
  "id": 73,
  "typeString": "enum",
  "cases": [
    {
  "name": "none case system case pinCertificate"
}
  ],
  "name": "ServerValidationPolicy"
},{
  "id": 74,
  "typeString": "struct",
  "properties": [
    {
  "name": "let user: SyncUser",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let realmURL: URL",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let stopPolicy: RLMSyncStopPolicy",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let serverValidationPolicy: ServerValidationPolicy @available(*, deprecated, message: )",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var enableSSLValidation: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isPartial: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let fullSynchronization: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let urlPrefix: String? @available(*, deprecated, message: ) @available(*, deprecated, message: ) @available(*, deprecated, message: )",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "asConfig() -> RLMSyncConfiguration",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "automatic() -> Realm.Configuration",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "automatic(user: SyncUser) -> Realm.Configuration",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "init(config: RLMSyncConfiguration)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "init(user: SyncUser, realmURL: URL, enableSSLValidation: Bool = true, isPartial: Bool = false, urlPrefix: String? = nil)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "SyncConfiguration"
},{
  "id": 75,
  "typeString": "struct",
  "properties": [
    {
  "name": "var token: Token",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var provider: Provider",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var userInfo: [String: Any] @available(*, deprecated, message: )",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "facebook(token: Token) -> SyncCredentials",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "google(token: Token) -> SyncCredentials",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "cloudKit(token: Token) -> SyncCredentials",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "usernamePassword(username: String, password: String, register: Bool = false) -> SyncCredentials",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "accessToken(_ accessToken: String, identity: String) -> SyncCredentials",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "jwt(_ token: Token) -> SyncCredentials",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "nickname(_ nickname: String, isAdmin: Bool = false) -> SyncCredentials",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "anonymous() -> SyncCredentials",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "customRefreshToken(_ token: String, identity: String, isAdmin: Bool = false) -> SyncCredentials",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "init(customToken token: Token, provider: Provider, userInfo: [String: Any] = [:])",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(_ credentials: RLMSyncCredentials)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "SyncCredentials"
},{
  "id": 76,
  "typeString": "enum",
  "cases": [
    {
  "name": "upload case download"
}
  ],
  "name": "ProgressDirection"
},{
  "id": 77,
  "typeString": "enum",
  "cases": [
    {
  "name": "reportIndefinitely case forCurrentlyOutstandingWork"
}
  ],
  "name": "ProgressMode"
},{
  "id": 78,
  "typeString": "struct",
  "properties": [
    {
  "name": "let transferredBytes: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let transferrableBytes: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var fractionTransferred: Double",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let percentage",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var isTransferComplete: Bool",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "init(transferred: UInt, transferrable: UInt)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "Progress"
},{
  "id": 79,
  "typeString": "enum",
  "methods": [
    {
  "name": "== (lhs: SyncSubscriptionState, rhs: SyncSubscriptionState) -> Bool",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "init(_ rlmSubscription: RLMSyncSubscription)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "cases": [
    {
  "name": "creating case pending case complete case invalidated case error"
}
  ],
  "name": "SyncSubscriptionState",
  "superClass": 208
},{
  "id": 80,
  "typeString": "class",
  "properties": [
    {
  "name": "let rlmSubscription: RLMSyncSubscription",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "var name: String?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var state: SyncSubscriptionState",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var query: String?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var createdAt: Date?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var updatedAt: Date?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var expiresAt: Date?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var timeToLive: TimeInterval?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let ttl",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "== (lhs: SyncSubscription, rhs: SyncSubscription) -> Bool",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "observe(_ keyPath: KeyPath<SyncSubscription, SyncSubscriptionState>, options: NSKeyValueObservingOptions = [], _ block: @escaping (SyncSubscriptionState) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "unsubscribe()",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(_ rlmSubscription: RLMSyncSubscription)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    43
  ],
  "name": "SyncSubscription",
  "extensions": [
    100
  ]
},{
  "id": 81,
  "typeString": "class",
  "properties": [
    {
  "name": "var observation: NSKeyValueObservation?",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "invalidate()",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(_ observation: NSKeyValueObservation)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "KeyValueObservationNotificationToken",
  "superClass": 211
},{
  "id": 82,
  "typeString": "class",
  "name": "SyncPermissionValue"
},{
  "id": 83,
  "typeString": "class",
  "properties": [
    {
  "name": "var role: PermissionRole? @objc dynamic",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var canRead",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var canUpdate",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var canDelete",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var canSetPermissions",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var canQuery",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var canCreate",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var canModifySchema",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "_realmObjectName() -> String",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "name": "Permission",
  "superClass": 169
},{
  "id": 84,
  "typeString": "class",
  "properties": [
    {
  "name": "var name",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let users",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "_realmObjectName() -> String",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "primaryKey() -> String",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "_realmColumnNames() -> [String: String]",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "name": "PermissionRole",
  "superClass": 169
},{
  "id": 85,
  "typeString": "class",
  "properties": [
    {
  "name": "var identity",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var role: PermissionRole?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let roles",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "_realmObjectName() -> String",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "primaryKey() -> String",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "_realmColumnNames() -> [String: String]",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "name": "PermissionUser",
  "superClass": 169
},{
  "id": 86,
  "typeString": "class",
  "properties": [
    {
  "name": "var id",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "let permissions",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "_realmObjectName() -> String",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "primaryKey() -> String",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "name": "RealmPermission",
  "superClass": 169
},{
  "id": 87,
  "typeString": "class",
  "properties": [
    {
  "name": "var name",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let permissions",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "_realmObjectName() -> String",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "primaryKey() -> String",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "name": "ClassPermission",
  "superClass": 169
},{
  "id": 88,
  "typeString": "struct",
  "properties": [
    {
  "name": "let rawValue: UInt8",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var debugDescription: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let read",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let update",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let setPermissions",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let modifySchema",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "init(rawValue: RawValue)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    213
  ],
  "name": "RealmPrivileges",
  "superClass": 212
},{
  "id": 89,
  "typeString": "struct",
  "properties": [
    {
  "name": "let rawValue: UInt8",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var debugDescription: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let read",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let create",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let update",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let subscribe",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let setPermissions",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "init(rawValue: RawValue)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "ClassPrivileges",
  "superClass": 212
},{
  "id": 90,
  "typeString": "struct",
  "properties": [
    {
  "name": "let rawValue: UInt8",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var debugDescription: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let read",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let update",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let delete",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let setPermissions",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "init(rawValue: RawValue)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "ObjectPrivileges",
  "superClass": 212
},{
  "id": 104,
  "typeString": "class",
  "properties": [
    {
  "name": "let objectClassName: String",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let propertyName: String",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var cachedRLMResults: RLMResults<AnyObject>? @objc",
  "type": "instance",
  "accessLevel": "fileprivate"
},
    {
  "name": "var object: RLMWeakObjectHandle? @objc",
  "type": "instance",
  "accessLevel": "fileprivate"
},
    {
  "name": "var property: RLMProperty?",
  "type": "instance",
  "accessLevel": "fileprivate"
},
    {
  "name": "var rlmResults: RLMResults<AnyObject>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let object",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let property",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "countByEnumerating(with state: UnsafeMutablePointer<NSFastEnumerationState>, objects buffer: AutoreleasingUnsafeMutablePointer<AnyObject?>, count len: Int) -> Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(fromClassName objectClassName: String, property propertyName: String)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "LinkingObjectsBase",
  "superClass": 193
},{
  "id": 105,
  "typeString": "class",
  "properties": [
    {
  "name": "var realm: Realm?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isInvalidated: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var count: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var this",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var first: Element?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var last: Element?",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "index(of object: Element) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(matching predicate: NSPredicate) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(matching predicateFormat: String, _ args: Any...) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "value(forKey key: String) -> Any?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "value(forKeyPath keyPath: String) -> Any?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "setValue(_ value: Any?, forKey key: String)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "filter(_ predicateFormat: String, _ args: Any...) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "filter(_ predicate: NSPredicate) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sorted(byKeyPath keyPath: String, ascending: Bool = true) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sorted<S: Sequence>(by sortDescriptors: S) -> Results<Element> where S.Iterator.Element == SortDescriptor",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "min<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "max<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sum<T: AddableType>(ofProperty property: String) -> T",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "average<T: AddableType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "observe(_ block: @escaping (RealmCollectionChange<LinkingObjects>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(fromType type: Element.Type, property propertyName: String)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "LinkingObjects",
  "superClass": 104,
  "extensions": [
    107,
    108
  ]
},{
  "id": 106,
  "typeString": "enum",
  "properties": [
    {
  "name": "var propertyName: String",
  "type": "instance",
  "accessLevel": "fileprivate"
},
    {
  "name": "let property): return property.name case .cached(",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let propertyName): return propertyName } }",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "cases": [
    {
  "name": "uncached"
},
    {
  "name": "cached"
}
  ],
  "name": "LinkingObjectsBridgingMetadata"
},{
  "id": 109,
  "typeString": "struct",
  "properties": [
    {
  "name": "let keyPath: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let ascending: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var rlmSortDescriptorValue: RLMSortDescriptor",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "reversed() -> SortDescriptor",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(keyPath: String, ascending: Bool = true)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "SortDescriptor",
  "extensions": [
    98,
    110,
    111,
    112,
    113
  ]
},{
  "id": 114,
  "typeString": "protocol",
  "properties": [
    {
  "name": "var realm: Realm?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var isInvalidated: Bool",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "ThreadConfined"
},{
  "id": 115,
  "typeString": "class",
  "properties": [
    {
  "name": "let swiftMetadata: Any?",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "var isInvalidated: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let objectiveCReference: RLMThreadSafeReference<RLMThreadConfined>",
  "type": "instance",
  "accessLevel": "private"
}
  ],
  "methods": [
    {
  "name": "resolve(in realm: Realm) -> Confined?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "init(to threadConfined: Confined)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "ThreadSafeReference"
},{
  "id": 117,
  "typeString": "class",
  "methods": [
    {
  "name": "convert<T>(object: Results<T>) -> RLMResults<AnyObject>",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: RLMResults<AnyObject>) -> Results<Object>",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert<T>(object: List<T>) -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: RLMArray<AnyObject>) -> List<Object>",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert<T>(object: LinkingObjects<T>) -> RLMResults<AnyObject>",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: RLMLinkingObjects<RLMObject>) -> Results<Object>",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: Realm) -> RLMRealm",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: RLMRealm) -> Realm",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: Migration) -> RLMMigration",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: RLMMigration) -> Migration",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: ObjectSchema) -> RLMObjectSchema",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: RLMObjectSchema) -> ObjectSchema",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: Property) -> RLMProperty",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: RLMProperty) -> Property",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: Realm.Configuration) -> RLMRealmConfiguration",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: RLMRealmConfiguration) -> Realm.Configuration",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: Schema) -> RLMSchema",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: RLMSchema) -> Schema",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: SortDescriptor) -> RLMSortDescriptor",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: RLMSortDescriptor) -> SortDescriptor",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: @escaping RLMShouldCompactOnLaunchBlock) -> (Int, Int) -> Bool",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "convert(object: @escaping (Int, Int) -> Bool) -> RLMShouldCompactOnLaunchBlock",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "name": "ObjectiveCSupport",
  "extensions": [
    164
  ]
},{
  "id": 118,
  "typeString": "protocol",
  "name": "MinMaxType"
},{
  "id": 119,
  "typeString": "protocol",
  "methods": [
    {
  "name": "init()",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "AddableType"
},{
  "id": 120,
  "typeString": "class",
  "properties": [
    {
  "name": "let rlmResults: RLMResults<AnyObject>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var realm: Realm?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isInvalidated: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var count: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var first: Element?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var last: Element?",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "countByEnumerating(with state: UnsafeMutablePointer<NSFastEnumerationState>, objects buffer: AutoreleasingUnsafeMutablePointer<AnyObject?>, count len: Int) -> Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(of object: Element) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(matching predicate: NSPredicate) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(matching predicateFormat: String, _ args: Any...) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "value(forKey key: String) -> Any?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "value(forKeyPath keyPath: String) -> Any?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "setValue(_ value: Any?, forKey key: String)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "filter(_ predicateFormat: String, _ args: Any...) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "filter(_ predicate: NSPredicate) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sorted(byKeyPath keyPath: String, ascending: Bool = true) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sorted<S: Sequence>(by sortDescriptors: S) -> Results<Element> where S.Iterator.Element == SortDescriptor",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "distinct<S: Sequence>(by keyPaths: S) -> Results<Element> where S.Iterator.Element == String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "min<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "max<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sum<T: AddableType>(ofProperty property: String) -> T",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "average<T: AddableType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "observe(_ block: @escaping (RealmCollectionChange<Results>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(_ rlmResults: RLMResults<AnyObject>)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "Results",
  "superClass": 193,
  "extensions": [
    99,
    101,
    139,
    140,
    141
  ]
},{
  "id": 142,
  "typeString": "class",
  "properties": [
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var count: Int",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "descriptionWithMaxDepth(_ depth: UInt) -> String",
  "type": "instance",
  "accessLevel": "private"
}
  ],
  "name": "ListBase",
  "superClass": 214
},{
  "id": 143,
  "typeString": "class",
  "properties": [
    {
  "name": "var realm: Realm?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isInvalidated: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var first: Element?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var last: Element?",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "index(of object: Element) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(matching predicate: NSPredicate) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(matching predicateFormat: String, _ args: Any...) -> Int?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "value(forKey key: String) -> [AnyObject]",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "value(forKeyPath keyPath: String) -> [AnyObject]",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "setValue(_ value: Any?, forKey key: String)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "filter(_ predicateFormat: String, _ args: Any...) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "filter(_ predicate: NSPredicate) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sorted(byKeyPath keyPath: String, ascending: Bool = true) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sorted<S: Sequence>(by sortDescriptors: S) -> Results<Element> where S.Iterator.Element == SortDescriptor",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "min<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "max<T: MinMaxType>(ofProperty property: String) -> T?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "sum<T: AddableType>(ofProperty property: String) -> T",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "average(ofProperty property: String) -> Double?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "append(_ object: Element)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "append<S: Sequence>(objectsIn objects: S) where S.Iterator.Element == Element",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "insert(_ object: Element, at index: Int)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "remove(at index: Int)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "removeAll()",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "replace(index: Int, object: Element)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "move(from: Int, to: Int)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "swapAt(_ index1: Int, _ index2: Int)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "observe(_ block: @escaping (RealmCollectionChange<List>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init()",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(rlmArray: RLMArray<AnyObject>)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "List",
  "superClass": 142,
  "extensions": [
    103,
    144,
    145,
    146,
    147,
    148,
    149,
    150,
    151,
    152
  ]
},{
  "id": 153,
  "typeString": "protocol",
  "properties": [
    {
  "name": "var objCValue: Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(objCValue: Any) -> Self",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "CustomObjectiveCBridgeable"
},{
  "id": 154,
  "typeString": "protocol",
  "properties": [
    {
  "name": "var bridged: (objectiveCValue: Any, metadata: Any?)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(from objectiveCValue: Any, with metadata: Any?) -> Self",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "name": "AssistedObjectiveCBridgeable"
},{
  "id": 162,
  "typeString": "struct",
  "properties": [
    {
  "name": "let rlmObjectSchema: RLMObjectSchema",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var properties: [Property]",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var className: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var objectClass: AnyClass",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var primaryKeyProperty: Property?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let rlmProperty",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let rlmProperty",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "init(_ rlmObjectSchema: RLMObjectSchema)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "ObjectSchema",
  "superClass": 206,
  "extensions": [
    163
  ]
},{
  "id": 165,
  "typeString": "struct",
  "properties": [
    {
  "name": "let rlmSchema: RLMSchema",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var objectSchema: [ObjectSchema]",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let rlmObjectSchema",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "init(_ rlmSchema: RLMSchema)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "Schema",
  "superClass": 206,
  "extensions": [
    166
  ]
},{
  "id": 167,
  "typeString": "struct",
  "properties": [
    {
  "name": "var oldSchema: Schema",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var newSchema: Schema",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var rlmMigration: RLMMigration @discardableResult @discardableResult",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "enumerateObjects(ofType typeName: String, _ block: MigrationObjectEnumerateBlock)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "create(_ typeName: String, value: Any = [:]) -> MigrationObject",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "delete(_ object: MigrationObject)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "deleteData(forType typeName: String) -> Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "renameProperty(onType typeName: String, from oldName: String, to newName: String)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(_ rlmMigration: RLMMigration)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "Migration"
},{
  "id": 169,
  "typeString": "class",
  "properties": [
    {
  "name": "var realm: Realm?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let rlmReam",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var objectSchema: ObjectSchema",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var isInvalidated: Bool",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "_rlmArray() -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "objectUtilClass(_ isSwift: Bool) -> AnyClass",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "primaryKey() -> String?",
  "type": "type",
  "accessLevel": "open"
},
    {
  "name": "ignoredProperties() -> [String]",
  "type": "type",
  "accessLevel": "open"
},
    {
  "name": "indexedProperties() -> [String]",
  "type": "type",
  "accessLevel": "open"
},
    {
  "name": "observe(_ block: @escaping (ObjectChange) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "dynamicList(_ propertyName: String) -> List<DynamicObject>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "isSameObject(as object: Object?) -> Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "init(value: Any)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(realm: RLMRealm, schema: RLMObjectSchema)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "init(value: Any, schema: RLMSchema)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    114
  ],
  "name": "Object",
  "superClass": 215,
  "extensions": [
    155,
    174,
    175
  ]
},{
  "id": 170,
  "typeString": "struct",
  "properties": [
    {
  "name": "let name: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let oldValue: Any?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let newValue: Any?",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "PropertyChange"
},{
  "id": 171,
  "typeString": "enum",
  "cases": [
    {
  "name": "error"
},
    {
  "name": "change"
},
    {
  "name": "deleted"
}
  ],
  "name": "ObjectChange"
},{
  "id": 172,
  "typeString": "class",
  "properties": [
    {
  "name": "let value",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let array",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "dynamicList(_ propertyName: String) -> List<DynamicObject>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "value(forUndefinedKey key: String) -> Any?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "setValue(_ value: Any?, forUndefinedKey key: String)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "shouldIncludeInDefaultSchema() -> Bool",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "name": "DynamicObject",
  "superClass": 169
},{
  "id": 173,
  "typeString": "class",
  "methods": [
    {
  "name": "swiftVersion() -> NSString",
  "type": "type",
  "accessLevel": "private"
},
    {
  "name": "ignoredPropertiesForClass(_ type: AnyClass) -> NSArray?",
  "type": "type",
  "accessLevel": "private"
},
    {
  "name": "indexedPropertiesForClass(_ type: AnyClass) -> NSArray?",
  "type": "type",
  "accessLevel": "private"
},
    {
  "name": "linkingObjectsPropertiesForClass(_ type: AnyClass) -> NSDictionary?",
  "type": "type",
  "accessLevel": "private"
},
    {
  "name": "baseName(forLazySwiftProperty name: String) -> String?",
  "type": "type",
  "accessLevel": "private"
},
    {
  "name": "getNonIgnoredMirrorChildren(for object: Any) -> [Mirror.Child]",
  "type": "type",
  "accessLevel": "private"
},
    {
  "name": "getOptionalPropertyMetadata(for child: Mirror.Child, at index: Int) -> RLMSwiftPropertyMetadata?",
  "type": "type",
  "accessLevel": "private"
},
    {
  "name": "getSwiftProperties(_ object: Any) -> [RLMSwiftPropertyMetadata]",
  "type": "type",
  "accessLevel": "private"
},
    {
  "name": "requiredPropertiesForClass(_: Any) -> [String]",
  "type": "type",
  "accessLevel": "private"
}
  ],
  "name": "ObjectUtil",
  "superClass": 193
},{
  "id": 176,
  "typeString": "protocol",
  "name": "RealmOptionalType",
  "extensions": [
    178
  ]
},{
  "id": 177,
  "typeString": "class",
  "properties": [
    {
  "name": "var value: Value?",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "init(_ value: Value? = nil)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "name": "RealmOptional",
  "superClass": 216,
  "extensions": [
    187
  ]
},{
  "id": 188,
  "typeString": "class",
  "properties": [
    {
  "name": "var desiredSize: CGSize",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "viewDidLoad()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "configureView(for parameters: Set<INParameter>, of interaction: INInteraction, interactiveBehavior: INUIInteractiveBehavior, context: INUIHostedViewContext, completion: @escaping (Bool, Set<INParameter>, CGSize) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "IntentViewController",
  "superClass": 195
},{
  "id": 189,
  "typeString": "class",
  "methods": [
    {
  "name": "handler(for intent: INIntent) -> Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "IntentHandler",
  "superClass": 192
},{
  "id": 190,
  "typeString": "class",
  "methods": [
    {
  "name": "handle(intent: MachineAlertsIntent, completion: @escaping (MachineAlertsIntentResponse) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "resolveFieldName(for intent: MachineAlertsIntent, with completion: @escaping (Enum4ResolutionResult) -> Void)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "MachineAlertsIntentHandler",
  "superClass": 193
},{
  "id": 191,
  "typeString": "class",
  "methods": [
    {
  "name": "setUp()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "tearDown()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "testExample()",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "testPerformanceExample()",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "name": "JD_FarmerTests",
  "superClass": 204
},{
  "id": 192,
  "typeString": "class",
  "name": "INExtension"
},{
  "id": 193,
  "typeString": "class",
  "name": "NSObject"
},{
  "id": 194,
  "typeString": "protocol",
  "name": "CreateNoteIntentHandling"
},{
  "id": 195,
  "typeString": "class",
  "name": "UIViewController"
},{
  "id": 196,
  "typeString": "protocol",
  "name": "INUIHostedViewControlling"
},{
  "id": 197,
  "typeString": "class",
  "name": "String",
  "extensions": [
    61
  ]
},{
  "id": 198,
  "typeString": "class",
  "name": "UIResponder"
},{
  "id": 199,
  "typeString": "protocol",
  "name": "UIApplicationDelegate"
},{
  "id": 200,
  "typeString": "protocol",
  "name": "CPApplicationDelegate"
},{
  "id": 201,
  "typeString": "protocol",
  "name": "CPMapTemplateDelegate"
},{
  "id": 202,
  "typeString": "class",
  "name": "View"
},{
  "id": 203,
  "typeString": "class",
  "name": "PreviewProvider"
},{
  "id": 204,
  "typeString": "class",
  "name": "XCTestCase"
},{
  "id": 205,
  "typeString": "class",
  "name": "Int",
  "extensions": [
    53,
    124,
    134,
    179
  ]
},{
  "id": 206,
  "typeString": "class",
  "name": "CustomStringConvertible"
},{
  "id": 207,
  "typeString": "class",
  "name": "IteratorProtocol"
},{
  "id": 208,
  "typeString": "class",
  "name": "Equatable"
},{
  "id": 209,
  "typeString": "class",
  "name": "RandomAccessCollection"
},{
  "id": 210,
  "typeString": "protocol",
  "name": "LazyCollectionProtocol"
},{
  "id": 211,
  "typeString": "class",
  "name": "NotificationToken",
  "extensions": [
    36
  ]
},{
  "id": 212,
  "typeString": "class",
  "name": "OptionSet"
},{
  "id": 213,
  "typeString": "protocol",
  "name": "CustomDebugStringConvertible"
},{
  "id": 214,
  "typeString": "class",
  "name": "RLMListBase"
},{
  "id": 215,
  "typeString": "class",
  "name": "RLMObjectBase"
},{
  "id": 216,
  "typeString": "class",
  "name": "RLMOptionalBase"
},{
  "id": 217,
  "typeString": "protocol",
  "name": "MKAnnotation"
},{
  "id": 218,
  "typeString": "class",
  "name": "Sequence",
  "extensions": [
    28
  ]
},{
  "id": 219,
  "typeString": "class",
  "name": "Optional",
  "extensions": [
    52,
    64,
    161
  ]
},{
  "id": 220,
  "typeString": "class",
  "name": "Int8",
  "extensions": [
    54,
    125,
    135,
    157,
    180
  ]
},{
  "id": 221,
  "typeString": "class",
  "name": "Int16",
  "extensions": [
    55,
    126,
    136,
    158,
    181
  ]
},{
  "id": 222,
  "typeString": "class",
  "name": "Int32",
  "extensions": [
    56,
    127,
    137,
    159,
    182
  ]
},{
  "id": 223,
  "typeString": "class",
  "name": "Int64",
  "extensions": [
    57,
    128,
    138,
    160,
    183
  ]
},{
  "id": 224,
  "typeString": "class",
  "name": "Float",
  "extensions": [
    58,
    123,
    133,
    156,
    184
  ]
},{
  "id": 225,
  "typeString": "class",
  "name": "Double",
  "extensions": [
    59,
    122,
    132,
    185
  ]
},{
  "id": 226,
  "typeString": "class",
  "name": "Bool",
  "extensions": [
    60,
    186
  ]
},{
  "id": 227,
  "typeString": "class",
  "name": "Date",
  "extensions": [
    62,
    129
  ]
},{
  "id": 228,
  "typeString": "class",
  "name": "Data",
  "extensions": [
    63
  ]
},{
  "id": 229,
  "typeString": "class",
  "name": "SyncManager",
  "extensions": [
    91
  ]
},{
  "id": 230,
  "typeString": "class",
  "name": "SyncError",
  "extensions": [
    92
  ]
},{
  "id": 231,
  "typeString": "class",
  "name": "RLMSyncCredentials",
  "extensions": [
    93
  ]
},{
  "id": 232,
  "typeString": "class",
  "name": "SyncUser",
  "extensions": [
    94
  ]
},{
  "id": 233,
  "typeString": "class",
  "name": "SyncSession",
  "extensions": [
    95
  ]
},{
  "id": 234,
  "typeString": "class",
  "name": "SyncPermission",
  "extensions": [
    97
  ]
},{
  "id": 235,
  "typeString": "protocol",
  "name": "ExpressibleByStringLiteral"
},{
  "id": 236,
  "typeString": "class",
  "name": "NSNumber",
  "extensions": [
    121,
    131
  ]
},{
  "id": 237,
  "typeString": "class",
  "name": "NSDate",
  "extensions": [
    130
  ]
},{
  "id": 238,
  "typeString": "protocol",
  "name": "Encodable"
},{
  "id": 239,
  "typeString": "protocol",
  "name": "MutableCollection"
},{
  "id": 240,
  "typeString": "protocol",
  "name": "RangeReplaceableCollection"
},{
  "id": 241,
  "typeString": "protocol",
  "name": "Decodable"
},{
  "id": 242,
  "typeString": "protocol",
  "name": "Codable"
},{
  "id": 15,
  "typeString": "extension",
  "protocols": [
    217
  ]
},{
  "id": 28,
  "typeString": "extension",
  "methods": [
    {
  "name": "compactMap<T>(_ fn: (Self.Iterator.Element) throws -> T?) rethrows -> [T]",
  "type": "instance",
  "accessLevel": "internal"
}
  ]
},{
  "id": 29,
  "typeString": "extension",
  "properties": [
    {
  "name": "var defaultConfiguration: Configuration",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "var syncConfiguration: SyncConfiguration?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var _syncConfiguration: SyncConfiguration?",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "var fileURL: URL?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var _path: String?",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "var inMemoryIdentifier: String?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var _inMemoryIdentifier: String?",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "var encryptionKey: Data?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var readOnly: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var schemaVersion: UInt64",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var migrationBlock: MigrationBlock?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var deleteRealmIfMigrationNeeded: Bool",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var shouldCompactOnLaunch: ((Int, Int) -> Bool)?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var objectTypes: [Object.Type]?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var customSchema: RLMSchema?",
  "type": "instance",
  "accessLevel": "private"
},
    {
  "name": "var disableFormatUpgrade: Bool",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var rlmConfiguration: RLMRealmConfiguration",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let configuration",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let fileURL",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let inMemoryIdentifier",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let syncConfiguration",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let shouldCompactOnLaunch",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "fromRLMRealmConfiguration(_ rlmConfiguration: RLMRealmConfiguration) -> Configuration",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "init(fileURL: URL? = URL(fileURLWithPath: RLMRealmPathForFile(), isDirectory: false), inMemoryIdentifier: String? = nil, syncConfiguration: SyncConfiguration? = nil, encryptionKey: Data? = nil, readOnly: Bool = false, schemaVersion: UInt64 = 0, migrationBlock: MigrationBlock? = nil, deleteRealmIfMigrationNeeded: Bool = false, shouldCompactOnLaunch: ((Int, Int) -> Bool)? = nil, objectTypes: [Object.Type]? = nil)",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 34,
  "typeString": "extension",
  "methods": [
    {
  "name": "== (lhs: Realm, rhs: Realm) -> Bool",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    208
  ]
},{
  "id": 35,
  "typeString": "extension"
},{
  "id": 36,
  "typeString": "extension",
  "methods": [
    {
  "name": "stop()",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 38,
  "typeString": "extension",
  "methods": [
    {
  "name": "== (lhs: Property, rhs: Property) -> Bool",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    208
  ]
},{
  "id": 40,
  "typeString": "extension",
  "properties": [
    {
  "name": "let fail: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let fileAccess: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let filePermissionDenied: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let fileExists: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let fileNotFound: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let incompatibleLockFile: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let fileFormatUpgradeRequired: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let addressSpaceExhausted: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let schemaMismatch: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "let incompatibleSyncedFile: Code",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "var code: Code",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let _nsError: NSError",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var backupConfiguration: Realm.Configuration?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let configuration",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "init(_nsError error: NSError)",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 51,
  "typeString": "extension",
  "methods": [
    {
  "name": "_rlmArray() -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "_nilValue() -> Self",
  "type": "type",
  "accessLevel": "public"
}
  ]
},{
  "id": 52,
  "typeString": "extension",
  "methods": [
    {
  "name": "_rlmArray() -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "_nilValue() -> Optional",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    43
  ]
},{
  "id": 53,
  "typeString": "extension",
  "protocols": [
    43
  ]
},{
  "id": 54,
  "typeString": "extension",
  "protocols": [
    43
  ]
},{
  "id": 55,
  "typeString": "extension",
  "protocols": [
    43
  ]
},{
  "id": 56,
  "typeString": "extension",
  "protocols": [
    43
  ]
},{
  "id": 57,
  "typeString": "extension",
  "protocols": [
    43
  ]
},{
  "id": 58,
  "typeString": "extension",
  "methods": [
    {
  "name": "_rlmArray() -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    43
  ]
},{
  "id": 59,
  "typeString": "extension",
  "methods": [
    {
  "name": "_rlmArray() -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    43
  ]
},{
  "id": 60,
  "typeString": "extension",
  "methods": [
    {
  "name": "_rlmArray() -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    43
  ]
},{
  "id": 61,
  "typeString": "extension",
  "methods": [
    {
  "name": "_rlmArray() -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    43
  ]
},{
  "id": 62,
  "typeString": "extension",
  "methods": [
    {
  "name": "_rlmArray() -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    43
  ]
},{
  "id": 63,
  "typeString": "extension",
  "methods": [
    {
  "name": "_rlmArray() -> RLMArray<AnyObject>",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    43
  ]
},{
  "id": 64,
  "typeString": "extension",
  "methods": [
    {
  "name": "_rlmInferWrappedType() -> Wrapped",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    46
  ]
},{
  "id": 65,
  "typeString": "extension",
  "methods": [
    {
  "name": "min() -> Element?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "max() -> Element?",
  "type": "instance",
  "accessLevel": "internal"
}
  ]
},{
  "id": 66,
  "typeString": "extension",
  "methods": [
    {
  "name": "min() -> Element.Wrapped?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "max() -> Element.Wrapped?",
  "type": "instance",
  "accessLevel": "internal"
}
  ]
},{
  "id": 67,
  "typeString": "extension",
  "methods": [
    {
  "name": "sum() -> Element",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "average() -> Double?",
  "type": "instance",
  "accessLevel": "internal"
}
  ]
},{
  "id": 68,
  "typeString": "extension",
  "methods": [
    {
  "name": "sum() -> Element.Wrapped",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "average() -> Double?",
  "type": "instance",
  "accessLevel": "internal"
}
  ]
},{
  "id": 69,
  "typeString": "extension",
  "methods": [
    {
  "name": "sorted(ascending: Bool = true) -> Results<Element>",
  "type": "instance",
  "accessLevel": "internal"
}
  ]
},{
  "id": 70,
  "typeString": "extension",
  "methods": [
    {
  "name": "sorted(ascending: Bool = true) -> Results<Element>",
  "type": "instance",
  "accessLevel": "internal"
}
  ]
},{
  "id": 71,
  "typeString": "extension",
  "properties": [
    {
  "name": "var bridged: (objectiveCValue: Any, metadata: Any?)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(from objectiveCValue: Any, with metadata: Any?) -> AnyRealmCollection",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    154
  ]
},{
  "id": 72,
  "typeString": "extension",
  "methods": [
    {
  "name": "sorted(byProperty property: String, ascending: Bool) -> Results<Element>",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "addNotificationBlock(_ block: @escaping (RealmCollectionChange<Self>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 91,
  "typeString": "extension",
  "properties": [
    {
  "name": "var shared: SyncManager",
  "type": "type",
  "accessLevel": "public"
}
  ]
},{
  "id": 92,
  "typeString": "extension",
  "methods": [
    {
  "name": "clientResetInfo() -> (String, SyncError.ActionToken)?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "deleteRealmUserInfo() -> SyncError.ActionToken?",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 93,
  "typeString": "extension",
  "methods": [
    {
  "name": "init(_ credentials: SyncCredentials)",
  "type": "instance",
  "accessLevel": "internal"
}
  ]
},{
  "id": 94,
  "typeString": "extension",
  "properties": [
    {
  "name": "var all: [String: SyncUser]",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "var current: SyncUser?",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "var errorHandler: ((SyncUser, SyncAuthError) -> Void)?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let newValue",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "logIn(with credentials: SyncCredentials, server authServerURL: URL, timeout: TimeInterval = 30, callbackQueue queue: DispatchQueue = DispatchQueue.main, onCompletion completion: @escaping UserCompletionBlock)",
  "type": "type",
  "accessLevel": "public"
},
    {
  "name": "retrievePermissions(callback: @escaping (SyncPermissionResults?, SyncPermissionError?) -> Void)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "createOfferForRealm(at url: URL, accessLevel: SyncAccessLevel, expiration: Date? = nil, callback: @escaping (String?, SyncPermissionError?) -> Void)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "configuration(realmURL: URL? = nil, fullSynchronization: Bool = false, enableSSLValidation: Bool = true, urlPrefix: String? = nil) -> Realm.Configuration",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "configuration(realmURL: URL? = nil, fullSynchronization: Bool = false, serverValidationPolicy: ServerValidationPolicy, urlPrefix: String? = nil) -> Realm.Configuration",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 95,
  "typeString": "extension",
  "properties": [
    {
  "name": "let transferredBytes: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let transferrableBytes: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var fractionTransferred: Double",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let percentage",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "var isTransferComplete: Bool",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "addProgressNotification(for direction: ProgressDirection, mode: ProgressMode, block: @escaping (Progress) -> Void) -> ProgressNotificationToken?",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "init(transferred: UInt, transferrable: UInt)",
  "type": "instance",
  "accessLevel": "internal"
}
  ]
},{
  "id": 96,
  "typeString": "extension",
  "properties": [
    {
  "name": "var syncSession: SyncSession?",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "subscribe<T: Object>(to objects: T.Type, where: String, completion: @escaping (Results<T>?, Swift.Error?) -> Void)",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 97,
  "typeString": "extension",
  "protocols": [
    43
  ]
},{
  "id": 98,
  "typeString": "extension",
  "methods": [
    {
  "name": "init(sortProperty: SyncPermissionSortProperty, ascending: Bool = true)",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 99,
  "typeString": "extension",
  "methods": [
    {
  "name": "sorted(bySortProperty sortProperty: SyncPermissionSortProperty, ascending: Bool = true) -> Results<Element>",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 100,
  "typeString": "extension",
  "properties": [
    {
  "name": "var objCValue: Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(objCValue: Any) -> SyncSubscription",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    153
  ]
},{
  "id": 101,
  "typeString": "extension",
  "methods": [
    {
  "name": "subscribe(named subscriptionName: String? = nil, limit: Int? = nil, update: Bool = false, timeToLive: TimeInterval? = nil, includingLinkingObjects: [String] = []) -> SyncSubscription<Element>",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 102,
  "typeString": "extension",
  "properties": [
    {
  "name": "var permissions: List<Permission>",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "getPrivileges() -> RealmPrivileges",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "getPrivileges(_ object: Object) -> ObjectPrivileges",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "getPrivileges<T: Object>(_ cls: T.Type) -> ClassPrivileges",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "getPrivileges(forClassNamed className: String) -> ClassPrivileges",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "permissions<T: Object>(forType cls: T.Type) -> List<Permission>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "permissions(forClassNamed className: String) -> List<Permission>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "subscriptions() -> Results<SyncSubscription<Object>>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "subscription(named: String) -> SyncSubscription<Object>?",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 103,
  "typeString": "extension",
  "methods": [
    {
  "name": "findOrCreate(forRoleNamed roleName: String) -> Permission",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "findOrCreate(forRole role: PermissionRole) -> Permission",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 107,
  "typeString": "extension",
  "properties": [
    {
  "name": "var startIndex: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var endIndex: Int",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "makeIterator() -> RLMIterator<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(after: Int) -> Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(before: Int) -> Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "_observe(_ block: @escaping (RealmCollectionChange<AnyRealmCollection<Element>>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    45
  ]
},{
  "id": 108,
  "typeString": "extension",
  "properties": [
    {
  "name": "var bridged: (objectiveCValue: Any, metadata: Any?)",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let results",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(from objectiveCValue: Any, with metadata: Any?) -> LinkingObjects",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    154
  ]
},{
  "id": 110,
  "typeString": "extension",
  "properties": [
    {
  "name": "var description: String",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "let direction",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    206
  ]
},{
  "id": 111,
  "typeString": "extension",
  "methods": [
    {
  "name": "== (lhs: SortDescriptor, rhs: SortDescriptor) -> Bool",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    208
  ]
},{
  "id": 112,
  "typeString": "extension",
  "methods": [
    {
  "name": "init(unicodeScalarLiteral value: UnicodeScalarLiteralType)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(extendedGraphemeClusterLiteral value: ExtendedGraphemeClusterLiteralType)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(stringLiteral value: StringLiteralType)",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    235
  ]
},{
  "id": 113,
  "typeString": "extension",
  "properties": [
    {
  "name": "var property: String",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "init(property: String, ascending: Bool = true)",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 116,
  "typeString": "extension",
  "methods": [
    {
  "name": "resolve<Confined>(_ reference: ThreadSafeReference<Confined>) -> Confined?",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 121,
  "typeString": "extension",
  "protocols": [
    118
  ]
},{
  "id": 122,
  "typeString": "extension",
  "protocols": [
    118
  ]
},{
  "id": 123,
  "typeString": "extension",
  "protocols": [
    118
  ]
},{
  "id": 124,
  "typeString": "extension",
  "protocols": [
    118
  ]
},{
  "id": 125,
  "typeString": "extension",
  "protocols": [
    118
  ]
},{
  "id": 126,
  "typeString": "extension",
  "protocols": [
    118
  ]
},{
  "id": 127,
  "typeString": "extension",
  "protocols": [
    118
  ]
},{
  "id": 128,
  "typeString": "extension",
  "protocols": [
    118
  ]
},{
  "id": 129,
  "typeString": "extension",
  "protocols": [
    118
  ]
},{
  "id": 130,
  "typeString": "extension",
  "protocols": [
    118
  ]
},{
  "id": 131,
  "typeString": "extension",
  "protocols": [
    119
  ]
},{
  "id": 132,
  "typeString": "extension",
  "protocols": [
    119
  ]
},{
  "id": 133,
  "typeString": "extension",
  "protocols": [
    119
  ]
},{
  "id": 134,
  "typeString": "extension",
  "protocols": [
    119
  ]
},{
  "id": 135,
  "typeString": "extension",
  "protocols": [
    119
  ]
},{
  "id": 136,
  "typeString": "extension",
  "protocols": [
    119
  ]
},{
  "id": 137,
  "typeString": "extension",
  "protocols": [
    119
  ]
},{
  "id": 138,
  "typeString": "extension",
  "protocols": [
    119
  ]
},{
  "id": 139,
  "typeString": "extension",
  "properties": [
    {
  "name": "var startIndex: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var endIndex: Int",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "makeIterator() -> RLMIterator<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(after i: Int) -> Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(before i: Int) -> Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "_observe(_ block: @escaping (RealmCollectionChange<AnyRealmCollection<Element>>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    45
  ]
},{
  "id": 140,
  "typeString": "extension",
  "properties": [
    {
  "name": "var bridged: (objectiveCValue: Any, metadata: Any?)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(from objectiveCValue: Any, with metadata: Any?) -> Results",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    154
  ]
},{
  "id": 141,
  "typeString": "extension",
  "methods": [
    {
  "name": "encode(to encoder: Encoder) throws",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    238
  ]
},{
  "id": 144,
  "typeString": "extension",
  "methods": [
    {
  "name": "min() -> Element?",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "max() -> Element?",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 145,
  "typeString": "extension",
  "methods": [
    {
  "name": "sum() -> Element",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "average() -> Double?",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 146,
  "typeString": "extension",
  "properties": [
    {
  "name": "var startIndex: Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "var endIndex: Int",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "methods": [
    {
  "name": "makeIterator() -> RLMIterator<Element>",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "replaceSubrange<C: Collection, R>(_ subrange: R, with newElements: C) where C.Iterator.Element == Element, R: RangeExpression, List<Element>.Index == R.Bound",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "replaceSubrange<C: Collection>(_ subrange: Range<Int>, with newElements: C) where C.Iterator.Element == Element",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(after i: Int) -> Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "index(before i: Int) -> Int",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "_observe(_ block: @escaping (RealmCollectionChange<AnyRealmCollection<Element>>) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    45
  ]
},{
  "id": 147,
  "typeString": "extension",
  "methods": [
    {
  "name": "removeFirst(_ number: Int = 1)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "removeLast(_ number: Int = 1)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "insert<C: Collection>(contentsOf newElements: C, at i: Int) where C.Iterator.Element == Element",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "removeSubrange<R>(_ boundsExpression: R) where R: RangeExpression, List<Element>.Index == R.Bound",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "removeSubrange(_ bounds: Range<Int>)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "removeSubrange(_ bounds: ClosedRange<Int>)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "removeSubrange(_ bounds: CountableRange<Int>)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "removeSubrange(_ bounds: CountableClosedRange<Int>)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "removeSubrange(_ bounds: DefaultRandomAccessIndices<List>)",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "replaceSubrange<C: Collection>(_ subrange: ClosedRange<Int>, with newElements: C) where C.Iterator.Element == Element",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "replaceSubrange<C: Collection>(_ subrange: CountableRange<Int>, with newElements: C) where C.Iterator.Element == Element",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "replaceSubrange<C: Collection>(_ subrange: CountableClosedRange<Int>, with newElements: C) where C.Iterator.Element == Element",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "replaceSubrange<C: Collection>(_ subrange: DefaultRandomAccessIndices<List>, with newElements: C) where C.Iterator.Element == Element",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    239
  ]
},{
  "id": 148,
  "typeString": "extension",
  "methods": [
    {
  "name": "removeLast()",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    240
  ]
},{
  "id": 149,
  "typeString": "extension",
  "methods": [
    {
  "name": "init(from decoder: Decoder) throws",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    241
  ]
},{
  "id": 150,
  "typeString": "extension",
  "methods": [
    {
  "name": "encode(to encoder: Encoder) throws",
  "type": "instance",
  "accessLevel": "public"
}
  ],
  "protocols": [
    238
  ]
},{
  "id": 151,
  "typeString": "extension",
  "properties": [
    {
  "name": "var bridged: (objectiveCValue: Any, metadata: Any?)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(from objectiveCValue: Any, with metadata: Any?) -> List",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    154
  ]
},{
  "id": 152,
  "typeString": "extension",
  "methods": [
    {
  "name": "remove(objectAtIndex: Int)",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 155,
  "typeString": "extension",
  "methods": [
    {
  "name": "unsafeCastToRLMObject() -> RLMObject",
  "type": "instance",
  "accessLevel": "internal"
}
  ]
},{
  "id": 156,
  "typeString": "extension",
  "properties": [
    {
  "name": "var objCValue: Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(objCValue: Any) -> Float",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    153
  ]
},{
  "id": 157,
  "typeString": "extension",
  "properties": [
    {
  "name": "var objCValue: Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(objCValue: Any) -> Int8",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    153
  ]
},{
  "id": 158,
  "typeString": "extension",
  "properties": [
    {
  "name": "var objCValue: Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(objCValue: Any) -> Int16",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    153
  ]
},{
  "id": 159,
  "typeString": "extension",
  "properties": [
    {
  "name": "var objCValue: Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(objCValue: Any) -> Int32",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    153
  ]
},{
  "id": 160,
  "typeString": "extension",
  "properties": [
    {
  "name": "var objCValue: Any",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(objCValue: Any) -> Int64",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    153
  ]
},{
  "id": 161,
  "typeString": "extension",
  "properties": [
    {
  "name": "var objCValue: Any",
  "type": "instance",
  "accessLevel": "internal"
},
    {
  "name": "let value",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(objCValue: Any) -> Optional",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    153
  ]
},{
  "id": 163,
  "typeString": "extension",
  "methods": [
    {
  "name": "== (lhs: ObjectSchema, rhs: ObjectSchema) -> Bool",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    208
  ]
},{
  "id": 164,
  "typeString": "extension",
  "methods": [
    {
  "name": "convert(object: SyncCredentials) -> RLMSyncCredentials",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "convert(object: RLMSyncCredentials) -> SyncCredentials",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "convert(object: SyncConfiguration) -> RLMSyncConfiguration",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "convert(object: RLMSyncConfiguration) -> SyncConfiguration",
  "type": "type",
  "accessLevel": "internal"
},
    {
  "name": "convert(object: RLMSyncSubscription) -> SyncSubscription<Object>",
  "type": "type",
  "accessLevel": "internal"
}
  ]
},{
  "id": 166,
  "typeString": "extension",
  "methods": [
    {
  "name": "== (lhs: Schema, rhs: Schema) -> Bool",
  "type": "type",
  "accessLevel": "public"
}
  ],
  "protocols": [
    208
  ]
},{
  "id": 168,
  "typeString": "extension",
  "methods": [
    {
  "name": "performMigration(for configuration: Realm.Configuration = Realm.Configuration.defaultConfiguration) throws",
  "type": "type",
  "accessLevel": "public"
}
  ]
},{
  "id": 174,
  "typeString": "extension",
  "properties": [
    {
  "name": "var bridged: (objectiveCValue: Any, metadata: Any?)",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "methods": [
    {
  "name": "bridging(from objectiveCValue: Any, with metadata: Any?) -> Self",
  "type": "type",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    154
  ]
},{
  "id": 175,
  "typeString": "extension",
  "methods": [
    {
  "name": "addNotificationBlock(_ block: @escaping (ObjectChange) -> Void) -> NotificationToken",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "isEqual(to object: Any?) -> Bool",
  "type": "instance",
  "accessLevel": "public"
}
  ]
},{
  "id": 178,
  "typeString": "extension",
  "methods": [
    {
  "name": "className() -> String",
  "type": "type",
  "accessLevel": "internal"
}
  ]
},{
  "id": 179,
  "typeString": "extension",
  "protocols": [
    176
  ]
},{
  "id": 180,
  "typeString": "extension",
  "protocols": [
    176
  ]
},{
  "id": 181,
  "typeString": "extension",
  "protocols": [
    176
  ]
},{
  "id": 182,
  "typeString": "extension",
  "protocols": [
    176
  ]
},{
  "id": 183,
  "typeString": "extension",
  "protocols": [
    176
  ]
},{
  "id": 184,
  "typeString": "extension",
  "protocols": [
    176
  ]
},{
  "id": 185,
  "typeString": "extension",
  "protocols": [
    176
  ]
},{
  "id": 186,
  "typeString": "extension",
  "protocols": [
    176
  ]
},{
  "id": 187,
  "typeString": "extension",
  "methods": [
    {
  "name": "encode(to encoder: Encoder) throws",
  "type": "instance",
  "accessLevel": "public"
},
    {
  "name": "init(from decoder: Decoder) throws",
  "type": "instance",
  "accessLevel": "internal"
}
  ],
  "protocols": [
    242
  ]
}] 